Action()
{
	web_set_max_html_param_len("9999999");
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");

	web_add_auto_header("priority", 
		"u=0, i");

	web_add_auto_header("sec-fetch-dest", 
		"document");

	web_add_auto_header("sec-fetch-mode", 
		"navigate");

	web_add_auto_header("sec-fetch-site", 
		"none");

	web_revert_auto_header("priority");

	web_add_auto_header("accept-encoding", 
		"gzip, deflate, br, zstd");

	web_add_auto_header("accept-language", 
		"en-US,en;q=0.9");

	web_add_auto_header("cache-control", 
		"no-cache");

	web_add_auto_header("pragma", 
		"no-cache");

	web_add_auto_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"129\", \"Not=A?Brand\";v=\"8\", \"Chromium\";v=\"129\"");

	web_add_auto_header("sec-ch-ua-mobile", 
		"?0");

	web_add_auto_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_add_header("sec-fetch-user", 
		"?1");

	web_add_header("upgrade-insecure-requests", 
		"1");

	web_add_auto_header("user-agent", 
		"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36");
	
	web_reg_save_param("c_CSRF3","LB=TEX_LOGIN_STATE=","RB=; Path=/;",LAST);
	
	web_reg_save_param("C_pingResume","LB=resumePath=%2Fas%2F","RB=%2Fresume%2Fas%2Fauthorization.ping&", LAST);
	
	web_reg_save_param("C_CSRF","LB=input type=\"hidden\" name=\"_csrf\" value=\"","RB=\"/>",LAST);
	
	web_reg_save_param("C_connectionId","LB=connectionId=","RB=&REF",LAST);
	
	web_reg_save_param("C_RefId","LB=REF=","RB=&unique_id",LAST);
	
	web_reg_save_param("C_uniqueId","LB=unique_id=","RB=&client",LAST);
	
	web_reg_save_param("C_clientId","LB=client_id=","RB=&dc",LAST);
	
	web_reg_save_param("C_dc","LB=dc=","RB=\r\n",LAST);
	
	web_reg_save_param("c_CSRF2","LB=XSRF-TOKEN=","RB=; Path=/",LAST);


	web_url("ui", 
		"URL=https://vipor.s.vsds.np.aws.mbride.net/ui/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("accept", 
		"application/json");

	web_add_auto_header("priority", 
		"u=1, i");

	web_add_auto_header("sec-fetch-dest", 
		"empty");

	web_add_auto_header("sec-fetch-mode", 
		"cors");

	web_add_auto_header("sec-fetch-site", 
		"same-origin");

	web_url("features", 
		"URL=https://login-int.mercedes-benz.com/features?uid=PID7E93", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://login-int.mercedes-benz.com/?instance=default&resumePath=%2Fas%2{C_pingResume}%2Fresume%2Fas%2Fauthorization.ping&allowInteraction=true&reauth=false&connectionId={C_connectionId}&REF={C_RefId}&unique_id={C_uniqueId}&clientEnv=caas&scope=openid+profile+email+offline_access+entitlement_group+basic_start_authorization&clientImpl=I3-Access_5.4.0&client_id={C_clientId}&dc={C_dc}", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("accept", 
		"application/json, text/plain, */*");

	web_url("time", 
		"URL=https://login-int.mercedes-benz.com/time", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://login-int.mercedes-benz.com/?instance=default&resumePath=%2Fas%2{C_pingResume}%2Fresume%2Fas%2Fauthorization.ping&allowInteraction=true&reauth=false&connectionId={C_connectionId}&REF={C_RefId}&unique_id={C_uniqueId}&clientEnv=caas&scope=openid+profile+email+offline_access+entitlement_group+basic_start_authorization&clientImpl=I3-Access_5.4.0&client_id={C_clientId}&dc={C_dc}",  
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");

	web_add_auto_header("origin", 
		"https://login-int.mercedes-benz.com");

	web_add_auto_header("priority", 
		"u=0, i");

	web_add_auto_header("sec-fetch-dest", 
		"document");

	web_add_auto_header("sec-fetch-mode", 
		"navigate");

	web_revert_auto_header("origin");

	web_revert_auto_header("priority");

	web_add_header("content-type", 
		"application/x-www-form-urlencoded");

	web_add_header("sec-fetch-user", 
		"?1");

	web_add_header("upgrade-insecure-requests", 
		"1");
	
	web_reg_save_param("c_TEX","LB=set-cookie: TEX=","RB=; Path=/;",LAST);

	web_submit_data("login-int.mercedes-benz.com", 
		"Action=https://login-int.mercedes-benz.com/", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://login-int.mercedes-benz.com/", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_csrf", "Value={C_CSRF}", ENDITEM, 
		"Name=password", "Value=!!Myjira111", ENDITEM, 
		"Name=scope", "Value=openid profile email offline_access entitlement_group authorization_group basic_start_authorization", ENDITEM, 
		"Name=dc", "Value={C_dc}", ENDITEM, 
		"Name=pingResume", "Value=/as/{C_pingResume}/resume/as/authorization.ping", ENDITEM, 
		"Name=instance", "Value=default", ENDITEM, 
		"Name=usedRememberMeSwitchId", "Value=", ENDITEM, 
		"Name=username", "Value=PID7E93", ENDITEM, 
		LAST);
	
	lr_start_transaction("T01_MBRide_Retail_New_DPG");


	web_add_cookie("TEX={c_TEX}; DOMAIN=vipor.s.vsds.np.aws.mbride.net");
	
	web_add_header("Postman-Token", 
		"2ca95677-b392-452c-8594-a3577c8e6a86");

	web_add_auto_header("Accept", 
		"*/*");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate");

	web_add_auto_header("Cache-Control", 
		"no-cache");

	web_add_auto_header("User-Agent", 
		"PostmanRuntime/7.42.0");
	
	web_reg_find("Search=All",
		"Text/IC=region",
		LAST);

	web_custom_request("summary", 
		"URL=https://vipor.s.vsds.np.aws.mbride.net/api/v1/viporhtml/api/vipor/retail/summary", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\r\n    \"monthYearCode\": null,\r\n    \"regionCode\": \"All\",\r\n    \"dealerCode\": \"All\",\r\n    \"areaCode\": \"All\",\r\n    \"marketCode\": \"All\",\r\n    \"customerLoanerCode\": \"I\",\r\n    \"vansSmartCode\": \"[\\\"01\\\", \\\"11\\\"]\",\r\n    \"touristCode\": \"ALL\",\r\n    \"monthYearName\": \"SEP 2024\",\r\n    \"regionName\": \"All\",\r\n    \"dealerName\": \"All\",\r\n    \"areaName\": \"All\",\r\n    \"marketName\": \"All\",\r\n    \"customerLoanerName\": \"Include\","
		"\r\n    \"vansSmartName\": \"Exclude Vans & smart\",\r\n    \"touristName\": \"Include\",\r\n    \"viewToShow\": \"region\",\r\n    \"currentMonth\": \"0\",\r\n    \"marketProgramCode\": \"All\",\r\n    \"pfdCode\": \"ALL\",\r\n    \"pfdName\": null,\r\n    \"preownedOrCpo\": null,\r\n    \"preOwnedOrCpoCode\": \"ALL\",\r\n    \"preOwnedOrCpoName\": null,\r\n    \"marketProgramDesc\": \"All\",\r\n    \"monthToShowInChart\": \"SEP 2024\",\r\n    \"dealerDescToShowInChart\": \"All\",\r\n    \""
		"procedureName\": \"P_VEH_SLSTK_RGNNAT_BYRGN\",\r\n    \"year\": null,\r\n    \"vpc\": \"All\",\r\n    \"vpcName\": \"All\",\r\n    \"vpcCode\": \"All\",\r\n    \"fleetType\": \"\",\r\n    \"fleetName\": null,\r\n    \"onLoad\": true,\r\n    \"invGroupCode\": null,\r\n    \"invGroupName\": null\r\n}", 
		LAST);
	
	lr_end_transaction("T01_MBRide_Retail_New_DPG", LR_AUTO);

	
	return 0;
}
