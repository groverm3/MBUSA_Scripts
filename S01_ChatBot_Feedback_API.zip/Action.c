Action()
{
	
	web_set_max_html_param_len("999999");
	
	
	web_set_sockets_option("SSL_VERSION", "AUTO");
	

	web_add_cookie("REMEMBER-ME-SWITCH=off; DOMAIN=login-int.mercedes-benz.com");

	web_add_cookie("REMEMBER-UID=PID6E93; DOMAIN=login-int.mercedes-benz.com");

	web_add_auto_header("accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");

	web_add_header("priority", 
		"u=0, i");

	web_add_header("sec-fetch-dest", 
		"document");

	web_add_header("sec-fetch-mode", 
		"navigate");

	web_add_auto_header("sec-fetch-site", 
		"none");


	web_add_header("accept-encoding", 
		"gzip, deflate, br, zstd");

	web_add_header("accept-language", 
		"en-US,en;q=0.9");

	web_add_header("cache-control", 
		"no-cache");

	web_add_header("pragma", 
		"no-cache");

	web_add_header("sec-ch-ua", 
		"\"Google Chrome\";v=\"129\", \"Not=A?Brand\";v=\"8\", \"Chromium\";v=\"129\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	web_add_header("sec-fetch-user", 
		"?1");

	web_add_header("upgrade-insecure-requests", 
		"1");
	
	web_reg_save_param("C_pingResume","LB=resumePath=%2Fas%2F","RB=%2Fresume%2Fas%2Fauthorization.ping&", LAST);
	
	web_reg_save_param("C_CSRF","LB=input type=\"hidden\" name=\"_csrf\" value=\"","RB=\"/>",LAST);
	
	web_reg_save_param("C_connectionId","LB=connectionId=","RB=&REF",LAST);
	
	web_reg_save_param("C_RefId","LB=REF=","RB=&unique_id",LAST);
	
	web_reg_save_param("C_uniqueId","LB=unique_id=","RB=&scope",LAST);
	
	web_reg_save_param("C_clientId","LB=client_id=","RB=&dc",LAST);
	
	web_reg_save_param("C_dc","LB=dc=","RB=\r\n",LAST);
	
	//web_reg_save_param("C_NETSTAR_SESSIONID","LB=set-cookie: NETSTAR_SESSIONID=","RB=; Path=/;",LAST);

	web_url("nsqafeature", 
		"URL=https://netstar-qa.i.mercedes-benz.com/nsqafeature/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("accept", 
		"application/json, text/plain, */*");

	web_add_header("priority", 
		"u=1, i");

	web_add_header("sec-fetch-dest", 
		"empty");

	web_add_header("sec-fetch-mode", 
		"cors");

	web_add_header("sec-fetch-site", 
		"same-origin");

	web_url("time", 
		"URL=https://login-int.mercedes-benz.com/time", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://login-int.mercedes-benz.com/?instance=default&resumePath=%2Fas%2{C_pingResume}%2Fresume%2Fas%2Fauthorization.ping&allowInteraction=true&reauth=false&connectionId={C_connectionId}&REF={C_RefId}&unique_id={C_uniqueId}&clientEnv=caas&scope=openid+profile+email+offline_access+entitlement_group+basic_start_authorization&clientImpl=I3-Access_5.4.0&client_id={C_clientId}&dc={C_dc}", 		
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("accept", 
		"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");

	web_add_header("priority", 
		"u=0, i");

	web_add_header("sec-fetch-dest", 
		"document");

	web_add_header("sec-fetch-mode", 
		"navigate");

	web_add_header("origin", 
		"https://login-int.mercedes-benz.com");

	web_add_header("content-type", 
		"application/x-www-form-urlencoded");

	web_add_header("sec-fetch-user", 
		"?1");

	web_add_header("upgrade-insecure-requests", 
		"1");
	
	web_reg_save_param("c_CSRF2","LB=set-cookie: XSRF-TOKEN=","RB=; Path=/;",LAST);
	
	web_reg_save_param("C_NETSTAR_SESSIONID1","LB=set-cookie: NETSTAR_SESSIONID=","RB=; Path=/;",LAST);

	web_submit_data("login-int.mercedes-benz.com", 
		"Action=https://login-int.mercedes-benz.com/", 
		"Method=POST", 
		"Resource=1",
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=_csrf", "Value={C_CSRF}", ENDITEM, 
		"Name=password", "Value=!!!Myjira111", ENDITEM, 
		/*"Name=password-encrypted", "Value=a/Q7e5FlVXZx9XOL4SlUJqTFm0jZALIEVmPy5TOOGAyl3a43L+B7fOatyVmGzViCsuXQeXjA4VGkJ+o1ULgR+wZFgVvQ+a+kd6uKBBVDYs9tC3FHF4B97PBKhR+4XoH4uEgAPOwiQeVxX4zTl+A7fbo7IVYKv1vIa3o6rUHh3A8nAMHX+8JIQs/ZLKtURnhxq48AjCLoK2X8J2+kAGniiH6Pe+EI15QefZSoJteVx2eXsNBy7ZA5HJPkFb3125I2lL4cL1KNaRXDqviHgh7Ut8RluwZBmPT2bQ796uqMVxV63A36xlV1MkdV7aArNc8y1iwNDZXHqrFAU0aCVp4qYg==", ENDITEM, */
		"Name=scope", "Value=openid authorization_group basic_start_authorization", ENDITEM, 
		"Name=dc", "Value={C_dc}", ENDITEM, 
		"Name=pingResume", "Value=/as/{C_pingResume}/resume/as/authorization.ping", ENDITEM, 
		"Name=instance", "Value=default", ENDITEM, 
		"Name=usedRememberMeSwitchId", "Value=", ENDITEM, 
		"Name=username", "Value=PID7E93", ENDITEM, 
		LAST);
	
	lr_think_time(1);
	
	lr_start_transaction("T01_ChatBot_Feedback_API");

	web_add_cookie("NETSTAR_SESSIONID={C_NETSTAR_SESSIONID1}; DOMAIN=netstar-qa.i.mercedes-benz.com");

	web_add_cookie("XSRF-TOKEN={c_CSRF2}; DOMAIN=netstar-qa.i.mercedes-benz.com");

	
	web_add_header("Content-Type", 
		"application/json");
	
	web_add_auto_header("Accept", 
		"*/*");

	web_add_auto_header("Accept-Encoding", 
		"gzip, deflate");

	web_add_auto_header("Cache-Control", 
		"no-cache");
	
	web_add_header("X-Xsrf-Token", 
		"{c_CSRF2}");
	
	web_reg_find("Search=Body",
		"Text/IC=feedbackId",
		LAST);
	
	web_custom_request("user", 
		"URL=https://netstar-qa.i.mercedes-benz.com/api/v1/chatbot/feedback/user", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\n    \"userId\": \"PID7E93\",\n    \"conversationId\": \"abc123\",\n    \"messageId\": \"\",\n    \"feedback\": 0,\n    \"description\": \"\",\n    \"feedbackTargetMsgDto\": {\n        \"query\": \"What is report of last quarter\",\n        \"response\": \"It was good\"\n    }\n}", 
		LAST);
	
	lr_end_transaction("T01_ChatBot_Feedback_API", LR_AUTO);

	
	return 0;
}
