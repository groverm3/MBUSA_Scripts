Action()
{
	int HTTP_rc;
	
	web_cache_cleanup();

	web_cleanup_cookies();
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("PF=fvEdUbvOmAGhhjXBcILeGe; DOMAIN=sso-int.mercedes-benz.com");

	web_add_cookie("PF_S=.em1009; DOMAIN=sso-int.mercedes-benz.com");
	
	web_reg_save_param("c_Accesstoken", 
	                   "LB=access_token\":\"", 
	                   "RB=\",", 
	                   "Search=All", 
	                   LAST);


	web_submit_data("token.oauth2", 
		"Action=https://sso-int.mercedes-benz.com/as/token.oauth2", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=grant_type", "Value=client_credentials", ENDITEM, 
		"Name=client_id", "Value=d415c166-f5ca-40d5-b79d-d3f38bea00f0", ENDITEM, 
		"Name=client_secret", "Value=bhidSJvRufrHkotPAabsTsXjmbYiZigvbEwAriSxCipjsigDKrwbZCyZrczBeHpz", ENDITEM, 
		LAST);
	

	web_add_header("Authorization", lr_eval_string("Bearer {c_Accesstoken}"));
	
	lr_start_transaction("T01_Boomi_customerSearch_v2");
	
		web_add_header("X-ApplicationName", 
		"starAPI-MME");

	web_add_header("X-TrackingId", 
		"046b6c7f-0b8a-43b9-b35d-6489e6daee91");
	
	web_custom_request("dealers", 
		"URL=https://api-ndc-qa.corpinter.net/eai-partner-management/customer-profile-service/v2/US/customer/search?ciamId=p0ssuoksmpga3vtb", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json",		
		LAST);
	
	
	HTTP_rc = web_get_int_property(HTTP_INFO_RETURN_CODE);
	
	if (HTTP_rc == 200)
	{
		lr_end_transaction("T01_Boomi_customerSearch_v2", LR_PASS);
	}
	else
	{
		
		lr_end_transaction("T01_Boomi_customerSearch_v2", LR_FAIL);
	}
	
	return 0;
}
