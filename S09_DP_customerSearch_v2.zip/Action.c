Action()
{

	int HTTP_rc;
	
	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_user("rzf/mme", 
		lr_unmask("670e16c0505583b61741886964e4dce030e859"), 
		"mbservices-qa.corpinter.net:443");

	web_add_cookie("NSXLB.643a882d-aac4-4db3-8cf4-b897bd5e6b89.30b54441-ffcd-48e9-9b6d-32c6ff8c752e=Qr4Up3oaf3TxaA03DOxhjdLDvIOPP+bXpbnYHLdRvoxjuf+gT16Xb8A5kCyhph7d; DOMAIN=mbservices-qa.corpinter.net");

	web_add_cookie("NSXLB.e9b098fb-3c0c-4dfc-8813-18672b50300c.f7aa3431-4e71-4a0b-bd37-6de44912b66a=c43KZljKVhjaowYYJUexjsdRxW6HCUGzlu89XV5Cx2YFzlZnEqBgKDfGRvBfd0ztL6fyCztvIIigymgGyKc2qQ==; DOMAIN=mbservices-qa.corpinter.net");

		lr_start_transaction("T01_DP_customerSearch_v2");

	web_add_header("X-ApplicationName", 
		"starAPI-MME");

	web_add_header("X-TrackingId", 
		"046b6c7f-0b8a-43b9-b35d-6489e6daee91");

	web_custom_request("users", 
		"URL=https://mbservices-qa.corpinter.net/apij/starapi/customer/mdm/services/v2/cpd/search/users/?ciamId=p0ssuoksmpga3vtb", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);


	HTTP_rc = web_get_int_property(HTTP_INFO_RETURN_CODE);
	
	if (HTTP_rc == 200)
	{
		lr_end_transaction("T01_DP_customerSearch_v2", LR_PASS);
	}
	else
	{
		
		lr_end_transaction("T01_DP_customerSearch_v2", LR_FAIL);
	}

	return 0;
}